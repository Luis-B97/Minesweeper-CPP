#pragma once
#include "Tile.h"
#include <vector>
#include <cstdlib>
#include <ctime>
#include <SFML/Graphics.hpp>
#include <algorithm>
#include <map>
#include <iostream>
#include <fstream>
using namespace std;
using namespace sf;

class Controller
{
	int flagsavailable;
	int numbombs;
	int tilesrevealed;

	map<string, Texture> icontextures;
	vector<bool> tileids;
	vector<int> testcase1;
	vector<int> testcase2;
	vector<int> testcase3;


	Sprite debugicon;
	Sprite test1;
	Sprite test2;
	Sprite test3;
	Sprite smiley;

	Sprite hundreds;
	Sprite tens;
	Sprite ones;

	bool islost;
	bool isover;

public:
	vector<Tile> tiles;

	Controller();

	void RandomTileIds();
	void setTileIds(vector<int>& bits, bool oneortwo);
	void MakeTiles();

	void setBombStates();
	void setIcons();

	void update(RenderWindow& window);
	void debug();
	void draw(RenderWindow& window);

	void refreshCounter();
	void refreshSmiley();

	void loadTestBoard(int testIndex);
};

//sets flagsavailable to 50, reads all the textures, calls maketiles, randomtileids
Controller::Controller()
{
	srand(time(NULL));
	flagsavailable = 50;

	// Load test boards from files
	fstream file;
	string lineholder;

	// Load testcase1
	file.open("boards/testboard1.brd");
	if (file.is_open())
	{
		while (getline(file, lineholder))
		{
			auto iter = lineholder.begin();
			while (iter != lineholder.end())
			{
				int holder = (*iter) - 48;
				testcase1.push_back(holder);
				iter++;
			}
		}
	}
	file.close();

	// Load testcase2
	file.open("boards/testboard2.brd");
	if (file.is_open())
	{
		while (getline(file, lineholder))
		{
			auto iter = lineholder.begin();
			while (iter != lineholder.end())
			{
				int holder = (*iter) - 48;
				testcase2.push_back(holder);
				iter++;
			}
		}
	}
	file.close();


	// Load testcase3
	file.open("boards/testboard3.brd"); // Load data for test3
	if (file.is_open()) {
		while (getline(file, lineholder)) {
			auto iter = lineholder.begin();
			while (iter != lineholder.end()) {
				int holder = (*iter) - 48;
				testcase3.push_back(holder);
				iter++;
			}
		}
	}
	file.close();

	// Load textures
	Texture holder;
	holder.loadFromFile("images/debug.png"); //console buttons
	icontextures.emplace("debug", holder);
	holder.loadFromFile("images/test_1.png");
	icontextures.emplace("testone", holder);
	holder.loadFromFile("images/test_2.png");
	icontextures.emplace("testtwo", holder);
	holder.loadFromFile("images/test_3.png"); // Load test3 texture
	icontextures.emplace("testthree", holder);

	holder.loadFromFile("images/digits.png"); //digits
	icontextures.emplace("digits", holder);

	holder.loadFromFile("images/face_happy.png"); //face button
	icontextures.emplace("happy", holder);
	holder.loadFromFile("images/face_lose.png");
	icontextures.emplace("lose", holder);
	holder.loadFromFile("images/face_win.png");
	icontextures.emplace("win", holder);

	holder.loadFromFile("images/flag.png"); //tile icons
	icontextures.emplace("flag", holder);
	holder.loadFromFile("images/mine.png");
	icontextures.emplace("bomb", holder);
	holder.loadFromFile("images/number_1.png");
	icontextures.emplace("one", holder);
	holder.loadFromFile("images/number_2.png");
	icontextures.emplace("two", holder);
	holder.loadFromFile("images/number_3.png");
	icontextures.emplace("three", holder);
	holder.loadFromFile("images/number_4.png");
	icontextures.emplace("four", holder);
	holder.loadFromFile("images/number_5.png");
	icontextures.emplace("five", holder);
	holder.loadFromFile("images/number_6.png");
	icontextures.emplace("six", holder);
	holder.loadFromFile("images/number_7.png");
	icontextures.emplace("seven", holder);
	holder.loadFromFile("images/number_8.png");
	icontextures.emplace("eight", holder);

	holder.loadFromFile("images/tile_hidden.png"); //tile states
	icontextures.emplace("hidden", holder);
	holder.loadFromFile("images/tile_revealed.png");
	icontextures.emplace("revealed", holder);

	// Set up sprites
	debugicon.setTexture(icontextures["debug"]);
	debugicon.setPosition(496, 512);
	test1.setTexture(icontextures["testone"]);
	test1.setPosition(560, 512);
	test2.setTexture(icontextures["testtwo"]);
	test2.setPosition(624, 512);
	test3.setTexture(icontextures["testthree"]); // Set test3 sprite
	test3.setPosition(688, 512); // Position for test3
	smiley.setTexture(icontextures["happy"]);
	smiley.setPosition(368, 512);

	hundreds.setTexture(icontextures["digits"]);
	hundreds.setTextureRect(Rect<int>(0, 0, 21, 32));
	hundreds.setPosition(0, 512);
	tens.setTexture(icontextures["digits"]);
	tens.setTextureRect(Rect<int>(21 * 5, 0, 21, 32));
	tens.setPosition(21, 512);
	ones.setTexture(icontextures["digits"]);
	ones.setTextureRect(Rect<int>(0, 0, 21, 32));
	ones.setPosition(42, 512);

	// Create the tiles and load random tile ids
	MakeTiles();
	RandomTileIds();
}
// Load the specified test board into the tile set
void Controller::loadTestBoard(int testIndex)
{
	vector<int> selectedTestCase;

	// Validate testIndex to prevent invalid values
	if (testIndex < 1 || testIndex > 3)
	{
		cout << "Error: Invalid test index " << testIndex << endl;
		return;
	}

	// Use the correct test case based on the test index
	switch (testIndex)
	{
	case 1:
		selectedTestCase = testcase1;
		break;
	case 2:
		selectedTestCase = testcase2;
		break;
	case 3:
		selectedTestCase = testcase3;
		break;
	}

	// Safely set tile IDs for the test case
	setTileIds(selectedTestCase, true);
	refreshCounter(); // Ensure counter is updated after board change
	refreshSmiley();  // Refresh smiley face
}




// creates a vector of 50 random numbers between 0 and 399, with no duplicates
//then uses that vector to create a vector of 400 bools, 50 of which will be true, and assign to tileids
//then calls seticons and setbombstates
void Controller::RandomTileIds()
{
	tileids.clear();
	vector<int> bits;
	int randomnum;
	bool getfree = false;

	for (int c = 0; c < 50; c++)
	{
		while (!getfree)
		{
			randomnum = rand() % 400;
			if (find(bits.begin(), bits.end(), randomnum) == bits.end())
			{
				bits.push_back(randomnum);
				getfree = true;
			}
		}
		getfree = false;
	}

	auto iter = bits.begin();
	for (int d = 0; d < 400; d++)
	{
		iter = find(bits.begin(), bits.end(), d);
		if (iter == bits.end())
		{
			tileids.push_back(false);
		}
		else
		{
			tileids.push_back(true);
		}
	}
	setBombStates();
	setIcons();
	flagsavailable = 50;
	refreshCounter();
	numbombs = 50;
	tilesrevealed = 0;

	islost = false;
	isover = false;
}

//takes in an array of 400 1s and 0s, and converts them to bools to set tileids
//then calls seticons and setbombstates
void Controller::setTileIds(vector<int>& bits, bool oneortwo)
{
	tileids.clear();
	for (int c = 0; c < 400; c++)
	{
		if (bits[c] == 0)
		{
			tileids.push_back(false);
		}
		else
		{
			tileids.push_back(true);
		}
	}
	setBombStates();
	setIcons();
	refreshCounter();
	if (oneortwo)
		numbombs = 1;
	else numbombs = 98;

	flagsavailable = numbombs;
	refreshCounter();

	islost = false;
	isover = false;
}



//instantiates the array of tiles, which will remain static over all games played during this instance
void Controller::MakeTiles()
{
	float x = 0; float y = 0;
	for (int c = 0; c < 16; c++)
	{
		for (int d = 0; d < 25; d++)
		{
			Tile t = Tile(icontextures, x, y);
			tiles.push_back(t);
			x += 32.f;
		}
		x = 0;
		y += 32.f;
	}
}

//calls setbombstate on each tile in tiles
//for use ONLY when the game is reset, otherwise you'll just make a big mess
void Controller::setBombStates()
{
	for (int c = 0; c < 400; c++)
	{
		tiles[c].setBombState(tileids[c]);
	}
}

//assigns icons to each tile based on isbomb and nearby bombs
void Controller::setIcons()
{
	for (int c = 0; c < 400; c++)
	{
		tiles[c].neighbors.clear();
		for (int d = 0; d < 8; d++)
		{
			tiles[c].neighbors.push_back(nullptr);
		}
		if (c == 0) //tile is top left corner
		{
			tiles[c].neighbors[4] = &(tiles[c + 1]);
			tiles[c].neighbors[6] = &(tiles[c + 25]);
			tiles[c].neighbors[7] = &(tiles[c + 26]);
		}
		else if (c == 24) // tile is top right corner
		{
			tiles[c].neighbors[3] = &(tiles[c - 1]);
			tiles[c].neighbors[5] = &(tiles[c + 24]);
			tiles[c].neighbors[6] = &(tiles[c + 25]);
		}
		else if (c == 375) // tile is bottom left corner
		{
			tiles[c].neighbors[4] = &(tiles[c + 1]);
			tiles[c].neighbors[1] = &(tiles[c - 25]);
			tiles[c].neighbors[2] = &(tiles[c - 24]);
		}
		else if (c == 399) // tile is bottom right corner
		{
			tiles[c].neighbors[3] = &(tiles[c - 1]);
			tiles[c].neighbors[1] = &(tiles[c - 25]);
			tiles[c].neighbors[0] = &(tiles[c - 26]);
		}
		else if (c < 24) // tile is on the top
		{
			tiles[c].neighbors[3] = &(tiles[c - 1]);
			tiles[c].neighbors[4] = &(tiles[c + 1]);
			tiles[c].neighbors[5] = &(tiles[c + 24]);
			tiles[c].neighbors[6] = &(tiles[c + 25]);
			tiles[c].neighbors[7] = &(tiles[c + 26]);
		}
		else if (c > 375) // tile is on the bottom
		{
			tiles[c].neighbors[3] = &(tiles[c - 1]);
			tiles[c].neighbors[4] = &(tiles[c + 1]);
			tiles[c].neighbors[2] = &(tiles[c - 24]);
			tiles[c].neighbors[1] = &(tiles[c - 25]);
			tiles[c].neighbors[0] = &(tiles[c - 26]);
		}
		else if ((c % 25) == 0) // tile is on the right edge
		{
			tiles[c].neighbors[4] = &(tiles[c + 1]);
			tiles[c].neighbors[6] = &(tiles[c + 25]);
			tiles[c].neighbors[7] = &(tiles[c + 26]);
			tiles[c].neighbors[1] = &(tiles[c - 25]);
			tiles[c].neighbors[2] = &(tiles[c - 24]);
		}
		else if (((c - 24) % 25) == 0) // tile is on the left edge
		{
			tiles[c].neighbors[3] = &(tiles[c - 1]);
			tiles[c].neighbors[0] = &(tiles[c - 26]);
			tiles[c].neighbors[1] = &(tiles[c - 25]);
			tiles[c].neighbors[5] = &(tiles[c + 24]);
			tiles[c].neighbors[6] = &(tiles[c + 25]);
		}
		else // tile is in the middle
		{
			tiles[c].neighbors[3] = &(tiles[c - 1]);
			tiles[c].neighbors[4] = &(tiles[c + 1]);
			tiles[c].neighbors[5] = &(tiles[c + 24]);
			tiles[c].neighbors[6] = &(tiles[c + 25]);
			tiles[c].neighbors[7] = &(tiles[c + 26]);
			tiles[c].neighbors[2] = &(tiles[c - 24]);
			tiles[c].neighbors[1] = &(tiles[c - 25]);
			tiles[c].neighbors[0] = &(tiles[c - 26]);
		}
		tiles[c].updateIcon(icontextures);
	}
}



//checks for left and right clicks
void Controller::update(RenderWindow& window)
{
	if (Mouse::isButtonPressed(Mouse::Left))
	{
		Vector2i mousePos = Mouse::getPosition(window);

			
	
		Vector2i position = Mouse::getPosition(window);
		if (position.y >= 0 && position.y < 512 && !isover)
		{
			if (position.x >= 0 && position.x <= 800)
			{
				int x = (position.x / 32);
				int y = (position.y / 32);

				int pos = (y * 25) + x;
				int count = 0;
				if (tiles[pos].reveal(count))
				{
					islost = true;
					isover = true;
					int dummycount = 0;
					for (int c = 0; c < 400; c++)
					{
						if (tiles[c].isflagged && tiles[c].isbomb)
							tiles[c].toggleFlag();
						if (tiles[c].isbomb)
							tiles[c].reveal(dummycount);
					}
				}
				else tilesrevealed += count;
			}
		}
		else if (position.y >= 512 && position.y < 572)
		{
			if (position.x >= 368 && position.x < 432)
			{
				RandomTileIds();
			}
			if (position.x >= 496 && position.x < 560 && !isover)
			{
				debug();
			}
			if (position.x >= 560 && position.x < 624 && !isover)
			{
				setTileIds(testcase1, true);
			}
			if (position.x >= 624 && position.x < 688 && !isover)
			{
				setTileIds(testcase2, false);
			}
			if (position.x >= 688 && position.x < 755 && !isover)
			{
				setTileIds(testcase3, false);
			}
		}
	}

	if (Mouse::isButtonPressed(Mouse::Right) && !isover)
	{
		Vector2i position = Mouse::getPosition(window);
		if (position.x >= 0 && position.x <= 800)
		{
			if (position.y >= 0 && position.y <= 512)
			{
				int x = (position.x / 32);
				int y = (position.y / 32);

				int pos = (y * 25) + x;
				if (!tiles[pos].isflagged && !tiles[pos].isrevealed)
				{
					tiles[pos].toggleFlag();
					flagsavailable--;
				}
				else if (!tiles[pos].isrevealed && tiles[pos].isflagged)
				{
					tiles[pos].toggleFlag();
					flagsavailable++;
				}
				refreshCounter();
			}
		}
	}

	if (tilesrevealed == (400 - numbombs) && !islost)
	{
		isover = true;
		for (int e = 0; e < 400; e++)
		{
			if (tiles[e].isbomb && !tiles[e].isflagged)
			{
				tiles[e].toggleFlag();
			}
		}
	}

	refreshSmiley();

	draw(window);
}

//calls toggleDebug on each tile
void Controller::debug()
{
	for (int c = 0; c < 400; c++)
	{
		tiles[c].toggleDebug();
	}
}

//calls draw on each tile in tiles
void Controller::draw(RenderWindow& window)
{
	for (int c = 0; c < 400; c++)
		tiles[c].draw(window);

	window.draw(smiley);
	window.draw(debugicon);
	window.draw(test1);
	window.draw(test2);
	window.draw(test3); // Draw the test3 button


	window.draw(hundreds);
	window.draw(tens);
	window.draw(ones);
}

void Controller::refreshCounter()
{
	int copy = flagsavailable;
	int onesplace = copy % 10;
	copy /= 10;
	int tensplace = copy % 10;

	tens.setTextureRect(Rect<int>(21 * tensplace, 0, 21, 32));
	ones.setTextureRect(Rect<int>(21 * onesplace, 0, 21, 32));
}

void Controller::refreshSmiley()
{
	if (isover)
	{
		if (islost)
			smiley.setTexture(icontextures["lose"]);
		else
			smiley.setTexture(icontextures["win"]);
	}
	else smiley.setTexture(icontextures["happy"]);
}